package com.example.chestcounter

import android.content.Context
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Спектр: 32 лог-полосы на кадр. */
object Spec {
    const val SR = 44100
    const val FRAME = 2048
    const val HOP = 1024
    const val BANDS = 32
    const val REF_FRAMES = 40 // ~0.93 c

    private val window = FloatArray(FRAME) { (0.5 - 0.5 * cos(2 * PI * it / (FRAME - 1))).toFloat() }
    private val edges = IntArray(BANDS + 1) { i ->
        val f = 100.0 * (12000.0 / 100.0).pow(i.toDouble() / BANDS)
        (f * FRAME / SR).toInt().coerceIn(1, FRAME / 2)
    }

    fun bands(s: ShortArray): FloatArray {
        val re = FloatArray(FRAME)
        val im = FloatArray(FRAME)
        for (i in 0 until FRAME) re[i] = s[i] / 32768f * window[i]
        fft(re, im)
        val out = FloatArray(BANDS)
        for (b in 0 until BANDS) {
            val st = edges[b]
            val en = max(edges[b + 1], st + 1).coerceAtMost(FRAME / 2)
            var sum = 0f
            for (k in st until en) sum += re[k] * re[k] + im[k] * im[k]
            out[b] = ln(sum / (en - st) + 1e-9f)
        }
        return out
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2 * PI / len
            val wr = cos(ang).toFloat()
            val wi = sin(ang).toFloat()
            val half = len / 2
            var i = 0
            while (i < n) {
                var cr = 1f
                var ci = 0f
                for (k in 0 until half) {
                    val ur = re[i + k]; val ui = im[i + k]
                    val xr = re[i + k + half]; val xi = im[i + k + half]
                    val vr = xr * cr - xi * ci
                    val vi = xr * ci + xi * cr
                    re[i + k] = ur + vr; im[i + k] = ui + vi
                    re[i + k + half] = ur - vr; im[i + k + half] = ui - vi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }
}

/** Сравнивает последние кадры звука с эталоном (нормированная корреляция). */
class Matcher(private val ref: Array<FloatArray>) {
    private val n = ref.size
    private val refVec = prep(ref.asList())
    private val ring = ArrayDeque<FloatArray>()

    fun push(frame: FloatArray): Float {
        ring.addLast(frame)
        if (ring.size > n) ring.removeFirst()
        if (ring.size < n) return 0f
        val v = prep(ring)
        var dot = 0f
        for (i in v.indices) dot += v[i] * refVec[i]
        return dot
    }

    private fun prep(m: List<FloatArray>): FloatArray {
        val t = m.size
        val out = FloatArray(t * Spec.BANDS)
        for (b in 0 until Spec.BANDS) {
            var mean = 0f
            for (i in 0 until t) mean += m[i][b]
            mean /= t
            for (i in 0 until t) out[i * Spec.BANDS + b] = m[i][b] - mean
        }
        var norm = 0f
        for (v in out) norm += v * v
        norm = sqrt(norm) + 1e-6f
        for (i in out.indices) out[i] /= norm
        return out
    }
}

/** Эталонный звук: извлечение из записи, сохранение, загрузка. */
object Ref {
    fun extract(pcm: ShortArray, len: Int): Array<FloatArray>? {
        val frames = ArrayList<FloatArray>()
        val w = ShortArray(Spec.FRAME)
        var pos = 0
        while (pos + Spec.FRAME <= len) {
            System.arraycopy(pcm, pos, w, 0, Spec.FRAME)
            frames.add(Spec.bands(w))
            pos += Spec.HOP
        }
        if (frames.size < Spec.REF_FRAMES + 4) return null
        val e = frames.map { it.average().toFloat() }
        var best = 2
        var bestRise = -Float.MAX_VALUE
        for (i in 2..(frames.size - Spec.REF_FRAMES + 2)) {
            val rise = e[i] - e[i - 2]
            if (rise > bestRise) { bestRise = rise; best = i }
        }
        val start = best - 2
        return Array(Spec.REF_FRAMES) { frames[start + it] }
    }

    fun save(ctx: Context, ref: Array<FloatArray>) {
        DataOutputStream(File(ctx.filesDir, "ref.bin").outputStream().buffered()).use { o ->
            o.writeInt(ref.size)
            for (f in ref) for (v in f) o.writeFloat(v)
        }
    }

    fun load(ctx: Context): Array<FloatArray>? {
        val f = File(ctx.filesDir, "ref.bin")
        if (!f.exists()) return null
        return try {
            DataInputStream(f.inputStream().buffered()).use { i ->
                val n = i.readInt()
                Array(n) { FloatArray(Spec.BANDS) { i.readFloat() } }
            }
        } catch (e: Exception) { null }
    }
}
