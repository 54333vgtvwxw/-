package com.example.chestcounter

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.max

/** Декодирует mp3/aac/wav/видео в моно 16 бит 44100 Гц. */
object AudioDecoder {
    fun decode(ctx: Context, uri: Uri): ShortArray? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)
                if (m != null && m.startsWith("audio/")) { track = i; break }
            }
            if (track < 0) return null
            ex.selectTrack(track)
            val fmt = ex.getTrackFormat(track)
            var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()

            var data = ShortArray(sr * ch * 4)
            var len = 0
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            val maxSamples = sr * ch * 20 // не больше 20 секунд
            while (!outDone) {
                if (!inDone) {
                    val ii = c.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val buf = c.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 10000)
                if (oi >= 0) {
                    val ob = c.getOutputBuffer(oi)!!
                    ob.position(info.offset)
                    ob.limit(info.offset + info.size)
                    val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                    val cnt = sb.remaining()
                    if (len + cnt > data.size) data = data.copyOf(max(data.size * 2, len + cnt))
                    sb.get(data, len, cnt)
                    len += cnt
                    c.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || len >= maxSamples) outDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = c.outputFormat
                    sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }

            val frames = len / ch
            if (frames < 1000) return null
            val mono = FloatArray(frames) { i ->
                var s = 0
                for (k in 0 until ch) s += data[i * ch + k]
                s / ch.toFloat()
            }
            val outLen = (frames.toLong() * Spec.SR / sr).toInt()
            return ShortArray(outLen) { i ->
                val pos = i.toDouble() * sr / Spec.SR
                val i0 = pos.toInt().coerceAtMost(frames - 1)
                val i1 = (i0 + 1).coerceAtMost(frames - 1)
                val fr = (pos - i0).toFloat()
                (mono[i0] * (1 - fr) + mono[i1] * fr).toInt().coerceIn(-32768, 32767).toShort()
            }
        } catch (e: Exception) {
            return null
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            ex.release()
        }
    }
}
