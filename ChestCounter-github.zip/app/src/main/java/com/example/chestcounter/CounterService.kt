package com.example.chestcounter

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread
import kotlin.math.max

class CounterService : Service() {
    companion object {
        const val ACTION_STOP = "stop"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_MIC = "mic"
        const val CH = "chest"
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private var wm: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var countTv: TextView? = null
    private var dbgTv: TextView? = null
    private var mp: MediaProjection? = null

    @Volatile private var running = false
    @Volatile private var recBuf: ShortArray? = null
    @Volatile private var matcher: Matcher? = null
    private var recLen = 0

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "count") main.post { countTv?.text = "📦 ${count()}" }
    }

    override fun onBind(i: Intent?): IBinder? = null

    private fun count() = prefs.getInt("count", 0)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopSelf(); return START_NOT_STICKY
        }
        val mic = intent.getBooleanExtra(EXTRA_MIC, false)

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Chest Counter", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, CH)
            .setContentTitle("Chest Counter слушает звук")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(
            1, notif,
            if (mic) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
        if (running) return START_NOT_STICKY

        prefs = getSharedPreferences("chest", MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        matcher = Ref.load(this)?.let { Matcher(it) }
        showOverlay()

        val rec = buildRecord(mic, intent)
        if (rec == null) {
            Toast.makeText(this, "Не удалось начать захват звука", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        if (matcher == null) dbgTv?.text = "нет эталона: удерживай"
        running = true
        thread(name = "audio") { loop(rec) }
        return START_NOT_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun buildRecord(mic: Boolean, intent: Intent): AudioRecord? = try {
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(Spec.SR)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val minBuf = AudioRecord.getMinBufferSize(Spec.SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val size = max(minBuf, Spec.HOP * 2 * 4)
        if (mic) {
            AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC)
                .setAudioFormat(fmt).setBufferSizeInBytes(size).build()
        } else {
            val code = intent.getIntExtra(EXTRA_CODE, 0)
            @Suppress("DEPRECATION")
            val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)!!
            val p = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
            mp = p
            val cfg = AudioPlaybackCaptureConfiguration.Builder(p)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(size)
                .setAudioPlaybackCaptureConfig(cfg).build()
        }
    } catch (e: Exception) { null }

    private fun loop(rec: AudioRecord) {
        val win = ShortArray(Spec.FRAME)
        val chunk = ShortArray(Spec.HOP)
        var lastHit = 0L
        var peak = 0f
        var n = 0
        rec.startRecording()
        while (running) {
            var got = 0
            while (got < Spec.HOP && running) {
                val r = rec.read(chunk, got, Spec.HOP - got)
                if (r < 0) { running = false; break }
                got += r
            }
            if (!running) break

            val rb = recBuf
            if (rb != null) {
                System.arraycopy(chunk, 0, rb, recLen, Spec.HOP)
                recLen += Spec.HOP
                if (recLen + Spec.HOP > rb.size) finishRecording(rb, recLen)
                continue
            }

            System.arraycopy(win, Spec.HOP, win, 0, Spec.FRAME - Spec.HOP)
            System.arraycopy(chunk, 0, win, Spec.FRAME - Spec.HOP, Spec.HOP)
            val m = matcher ?: continue
            val s = m.push(Spec.bands(win))
            if (s > peak) peak = s
            if (++n % 10 == 0) {
                val p = peak; peak = 0f
                main.post { dbgTv?.text = "%.2f".format(p) }
            }
            val now = SystemClock.elapsedRealtime()
            if (s >= prefs.getFloat("thr", 0.7f) && now - lastHit > 2500) {
                lastHit = now
                main.post { prefs.edit().putInt("count", count() + 1).apply() }
            }
        }
        try { rec.stop() } catch (_: Exception) {}
        rec.release()
    }

    private fun startRecording() {
        if (recBuf != null || !running) return
        dbgTv?.text = "REC 5 c — открой сундук"
        recLen = 0
        recBuf = ShortArray(Spec.SR * 5)
    }

    private fun finishRecording(rb: ShortArray, len: Int) {
        recBuf = null
        val ref = Ref.extract(rb, len)
        if (ref != null) {
            Ref.save(this, ref)
            matcher = Matcher(ref)
            main.post { dbgTv?.text = "✓ эталон сохранён" }
        } else {
            main.post { dbgTv?.text = "✗ не получилось" }
        }
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val ctv = TextView(this).apply {
            text = "📦 ${count()}"
            setTextColor(Color.WHITE); textSize = 18f; typeface = Typeface.DEFAULT_BOLD
        }
        val dtv = TextView(this).apply { setTextColor(0xFFAAAAAA.toInt()); textSize = 10f }
        countTv = ctv; dbgTv = dtv
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = 12 * d }
            setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
            addView(ctv); addView(dtv)
            setOnClickListener { prefs.edit().putInt("count", count() + 1).apply() } // ручной +1
            setOnLongClickListener { startRecording(); true }                           // запись эталона
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = (12 * d).toInt(); y = (40 * d).toInt() }
        wm!!.addView(box, lp)
        overlay = box
    }

    override fun onDestroy() {
        running = false
        try { prefs.unregisterOnSharedPreferenceChangeListener(prefListener) } catch (_: Exception) {}
        mp?.stop()
        overlay?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
