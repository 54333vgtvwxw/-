package com.example.chestcounter

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max

class CounterService : Service() {
    companion object {
        const val ACTION_STOP = "stop"
        const val CH = "chest"
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private var wm: WindowManager? = null
    private var badge: TextView? = null

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "count") main.post { badge?.text = label() }
    }

    override fun onBind(i: Intent?): IBinder? = null

    private fun count() = prefs.getInt("count", 0)
    private fun label() = "📦 ${count()}"

    private fun add(n: Int) {
        prefs.edit().putInt("count", (count() + n).coerceAtLeast(0)).commit()
        badge?.text = label()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf(); return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Chest Counter", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, CH)
            .setContentTitle("Счётчик сундуков работает")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notif)
        }
        if (badge == null) {
            prefs = getSharedPreferences("chest", MODE_PRIVATE)
            prefs.registerOnSharedPreferenceChangeListener(listener)
            showBadge()
        }
        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showBadge() {
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w
        val d = resources.displayMetrics.density
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = prefs.getInt("bx", (12 * d).toInt())
            y = prefs.getInt("by", (40 * d).toInt())
        }
        val tv = TextView(this).apply {
            text = label()
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = 14 * d }
            setPadding((16 * d).toInt(), (8 * d).toInt(), (16 * d).toInt(), (8 * d).toInt())
            // тап = +1, долгий тап = -1, перетаскивание = двигать плашку
            setOnTouchListener(object : View.OnTouchListener {
                private var sx = 0
                private var sy = 0
                private var tx = 0f
                private var ty = 0f
                private var moved = false
                private var longFired = false
                private val slop = ViewConfiguration.get(this@CounterService).scaledTouchSlop
                private val longTap = Runnable {
                    if (!moved) { longFired = true; add(-1) }
                }

                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> {
                            sx = lp.x; sy = lp.y
                            tx = e.rawX; ty = e.rawY
                            moved = false; longFired = false
                            main.postDelayed(longTap, ViewConfiguration.getLongPressTimeout().toLong())
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = e.rawX - tx
                            val dy = e.rawY - ty
                            if (!moved && (abs(dx) > slop || abs(dy) > slop)) {
                                moved = true
                                main.removeCallbacks(longTap)
                            }
                            if (moved) {
                                val dm = resources.displayMetrics
                                lp.x = (sx - dx).toInt().coerceIn(0, max(0, dm.widthPixels - v.width))
                                lp.y = (sy + dy).toInt().coerceIn(0, max(0, dm.heightPixels - v.height))
                                w.updateViewLayout(v, lp)
                            }
                        }
                        MotionEvent.ACTION_UP -> {
                            main.removeCallbacks(longTap)
                            if (moved) {
                                prefs.edit().putInt("bx", lp.x).putInt("by", lp.y).commit()
                            } else if (!longFired) {
                                add(1)
                            }
                        }
                        MotionEvent.ACTION_CANCEL -> main.removeCallbacks(longTap)
                    }
                    return true
                }
            })
        }
        w.addView(tv, lp)
        badge = tv
    }

    override fun onDestroy() {
        try { prefs.unregisterOnSharedPreferenceChangeListener(listener) } catch (_: Exception) {}
        badge?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        badge = null
        super.onDestroy()
    }
}
