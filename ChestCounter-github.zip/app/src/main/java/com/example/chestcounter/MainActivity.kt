package com.example.chestcounter

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

@Suppress("DEPRECATION")
class MainActivity : Activity() {
    private val reqPerm = 1
    private val reqProj = 2
    private lateinit var prefs: SharedPreferences
    private lateinit var micBox: CheckBox

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("chest", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        fun tv(t: String) = TextView(this).apply { text = t; textSize = 15f; setPadding(0, pad / 2, 0, pad / 2) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        col.addView(tv("Счётчик сундуков Fortnite.\n\n1) Выдай разрешение «поверх других приложений».\n2) Нажми «Запустить».\n3) В игре ОДИН РАЗ удерживай плашку справа сверху, в течение 5 секунд открой сундук — это запишет эталон звука.\n4) Дальше счёт идёт сам. Тап по плашке = +1 вручную. Цифра под счётом — текущее сходство со звуком (0..1)."))
        col.addView(btn("Разрешить поверх приложений") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        micBox = CheckBox(this).apply { text = "Слушать микрофон (вместо звука игры)" }
        col.addView(micBox)
        col.addView(btn("Запустить") { onStart() })
        col.addView(btn("Остановить") {
            startService(Intent(this, CounterService::class.java).setAction(CounterService.ACTION_STOP))
        })
        col.addView(btn("Сбросить счётчик") { prefs.edit().putInt("count", 0).apply() })

        val thrTv = tv("")
        fun setThr(p: Int) {
            val v = 0.45f + p / 100f
            prefs.edit().putFloat("thr", v).apply()
            thrTv.text = "Порог срабатывания: %.2f (ниже — чувствительнее, но больше ложных)".format(v)
        }
        col.addView(thrTv)
        col.addView(SeekBar(this).apply {
            max = 50
            progress = ((prefs.getFloat("thr", 0.7f) - 0.45f) * 100).toInt().coerceIn(0, 50)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) = setThr(p)
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            setThr(progress)
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun onStart() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала разреши показ поверх приложений", Toast.LENGTH_LONG).show(); return
        }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { requestPermissions(missing.toTypedArray(), reqPerm); return }
        launch()
    }

    private fun launch() {
        if (micBox.isChecked) {
            startForegroundService(Intent(this, CounterService::class.java).putExtra(CounterService.EXTRA_MIC, true))
        } else {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            startActivityForResult(mpm.createScreenCaptureIntent(), reqProj)
        }
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launch()
        else Toast.makeText(this, "Нужен доступ к записи звука", Toast.LENGTH_LONG).show()
    }

    override fun onActivityResult(rc: Int, code: Int, data: Intent?) {
        super.onActivityResult(rc, code, data)
        if (rc == reqProj && code == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CounterService::class.java)
                    .putExtra(CounterService.EXTRA_CODE, code)
                    .putExtra(CounterService.EXTRA_DATA, data)
                    .putExtra(CounterService.EXTRA_MIC, false)
            )
        }
    }
}
