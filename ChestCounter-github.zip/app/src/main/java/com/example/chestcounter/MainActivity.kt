package com.example.chestcounter

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

@Suppress("DEPRECATION")
class MainActivity : Activity() {
    private val reqPerm = 1
    private val reqProj = 2
    private val reqAudio = 3
    private lateinit var prefs: SharedPreferences
    private lateinit var micBox: CheckBox
    private lateinit var countTv: TextView
    private lateinit var countEdit: EditText

    private val countListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "count") runOnUiThread { refreshCount() }
    }

    private fun refreshCount() {
        countTv.text = "📦 Сундуков: ${prefs.getInt("count", 0)}"
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("chest", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        fun tv(t: String) = TextView(this).apply { text = t; textSize = 15f; setPadding(0, pad / 2, 0, pad / 2) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        countTv = TextView(this).apply { textSize = 26f; setPadding(0, 0, 0, pad / 2) }
        col.addView(countTv)

        countEdit = EditText(this).apply {
            hint = "Сколько сундуков уже открыто"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        col.addView(countEdit)
        col.addView(btn("Установить это число") {
            val v = countEdit.text.toString().trim().toIntOrNull()
            if (v == null || v < 0) {
                Toast.makeText(this, "Введи число", Toast.LENGTH_SHORT).show()
            } else {
                prefs.edit().putInt("count", v).apply()
                countEdit.setText("")
                Toast.makeText(this, "Счётчик: $v", Toast.LENGTH_SHORT).show()
            }
        })

        col.addView(tv("Звук сундука: выбери файл с этим звуком (mp3, wav, m4a или даже видео). Можно также удержать плашку в игре 5 секунд и открыть сундук — запишется прямо из игры."))
        col.addView(btn("Выбрать файл с звуком сундука") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*"))
            }
            startActivityForResult(i, reqAudio)
        })

        col.addView(tv("Запуск: 1) разреши показ поверх приложений, 2) нажми «Запустить», 3) открой Fortnite. Тап по плашке = +1 вручную. Цифра под счётом на плашке — сходство со звуком (0..1). Счёт сохраняется сам."))
        col.addView(btn("Разрешить поверх приложений") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        micBox = CheckBox(this).apply { text = "Слушать микрофон (вместо звука игры)" }
        col.addView(micBox)
        col.addView(btn("Запустить") { onStartClick() })
        col.addView(btn("Остановить") {
            startService(Intent(this, CounterService::class.java).setAction(CounterService.ACTION_STOP))
        })

        val thrTv = tv("")
        fun setThr(p: Int) {
            val v = 0.45f + p / 100f
            prefs.edit().putFloat("thr", v).apply()
            thrTv.text = "Порог срабатывания: %.2f (ниже — чувствительнее, но больше ложных)".format(v)
        }
        col.addView(thrTv)
        col.addView(SeekBar(this).apply {
            max = 50
            progress = ((prefs.getFloat("thr", 0.7f) - 0.45f) * 100).toInt().coerceIn(0, 50)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) = setThr(p)
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            setThr(progress)
        })
        setContentView(ScrollView(this).apply { addView(col) })
        refreshCount()
    }

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(countListener)
        refreshCount()
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(countListener)
        super.onPause()
    }

    private fun onStartClick() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала разреши показ поверх приложений", Toast.LENGTH_LONG).show(); return
        }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { requestPermissions(missing.toTypedArray(), reqPerm); return }
        launch()
    }

    private fun launch() {
        if (micBox.isChecked) {
            startForegroundService(Intent(this, CounterService::class.java).putExtra(CounterService.EXTRA_MIC, true))
        } else {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            startActivityForResult(mpm.createScreenCaptureIntent(), reqProj)
        }
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launch()
        else Toast.makeText(this, "Нужен доступ к записи звука", Toast.LENGTH_LONG).show()
    }

    override fun onActivityResult(rc: Int, code: Int, data: Intent?) {
        super.onActivityResult(rc, code, data)
        if (rc == reqProj && code == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CounterService::class.java)
                    .putExtra(CounterService.EXTRA_CODE, code)
                    .putExtra(CounterService.EXTRA_DATA, data)
                    .putExtra(CounterService.EXTRA_MIC, false)
            )
        } else if (rc == reqAudio && code == RESULT_OK && data?.data != null) {
            val uri = data.data!!
            Toast.makeText(this, "Обрабатываю файл…", Toast.LENGTH_SHORT).show()
            Thread {
                val pcm = AudioDecoder.decode(this, uri)
                val ref = if (pcm != null) Ref.extract(pcm, pcm.size) else null
                if (ref != null) Ref.save(this, ref)
                runOnUiThread {
                    if (ref != null) Toast.makeText(this, "Эталон загружен ✓ (%.1f с)".format(ref.size * Spec.HOP / Spec.SR.toFloat()), Toast.LENGTH_LONG).show()
                    else Toast.makeText(this, "Не удалось прочитать звук. Нужен файл хотя бы ~0.4 с со звуком сундука", Toast.LENGTH_LONG).show()
                }
            }.start()
        }
    }
}
