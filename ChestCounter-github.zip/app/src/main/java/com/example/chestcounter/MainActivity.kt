package com.example.chestcounter

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

@Suppress("DEPRECATION")
class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var countTv: TextView
    private lateinit var countEdit: EditText

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "count") runOnUiThread { refresh() }
    }

    private fun refresh() {
        countTv.text = "📦 Сундуков: ${prefs.getInt("count", 0)}"
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("chest", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        countTv = TextView(this).apply { textSize = 28f; setPadding(0, 0, 0, pad) }
        col.addView(countTv)

        countEdit = EditText(this).apply {
            hint = "Введи число сундуков"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        col.addView(countEdit)
        col.addView(btn("Установить это число") {
            val v = countEdit.text.toString().trim().toIntOrNull()
            if (v == null || v < 0) {
                Toast.makeText(this, "Введи число", Toast.LENGTH_SHORT).show()
            } else {
                prefs.edit().putInt("count", v).commit()
                countEdit.setText("")
            }
        })

        col.addView(TextView(this).apply {
            text = "\n1) Разреши показ поверх приложений.\n2) Нажми «Запустить плашку».\n3) В игре тапай по плашке справа сверху: +1. Долгий тап: −1.\nСчёт сохраняется сам."
            textSize = 15f
        })
        col.addView(btn("Разрешить поверх приложений") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("Запустить плашку") { onStartClick() })
        col.addView(btn("Остановить плашку") {
            startService(Intent(this, CounterService::class.java).setAction(CounterService.ACTION_STOP))
        })
        setContentView(ScrollView(this).apply { addView(col) })
        refresh()
    }

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(listener)
        refresh()
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
        super.onPause()
    }

    private fun onStartClick() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала разреши показ поверх приложений", Toast.LENGTH_LONG).show(); return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1); return
        }
        launch()
    }

    private fun launch() {
        startForegroundService(Intent(this, CounterService::class.java))
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        launch() // плашка работает и без уведомления
    }
}
